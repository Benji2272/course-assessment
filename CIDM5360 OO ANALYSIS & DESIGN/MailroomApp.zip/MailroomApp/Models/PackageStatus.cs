namespace MailroomApp.Models
{
    public enum PackageStatus
    {
        Pending,
        PickedUp,
        Returned,
        Unknown
    }
}
