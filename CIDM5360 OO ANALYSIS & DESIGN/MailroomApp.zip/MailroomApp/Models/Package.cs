using System;

namespace MailroomApp.Models
{
    public class Package
    {
        public int Id { get; set; }
        public string TrackingId { get; set; } = "";
        public string Carrier { get; set; } = "";
        public PackageStatus Status { get; set; }

        public DateTime DeliveredDate { get; set; }
        public DateTime? PickedUpDate { get; set; }
        public string? UnknownNote { get; set; }

        // null for unknown packages
        public Resident? Resident { get; set; }
    }
}
