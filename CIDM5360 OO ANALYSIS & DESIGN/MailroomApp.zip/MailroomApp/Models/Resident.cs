namespace MailroomApp.Models
{
    public class Resident
    {
        public int Id { get; set; }
        public string FullName { get; set; } = "";
        public string Email { get; set; } = "";
        public string UnitNumber { get; set; } = "";
    }
}
