using System;
using System.Collections.Generic;
using System.Linq;
using MailroomApp.Services;

namespace MailroomApp.Models
{
    public class MailroomSystem
    {
        private readonly List<StaffUser> _staffUsers = new();
        private readonly List<Resident> _residents = new();
        private readonly List<Package> _packages = new();
        private readonly IEmailService _emailService;

        private int _nextPackageId = 1;

        public MailroomSystem(IEmailService emailService)
        {
            _emailService = emailService;
            SeedData();
        }

        private void SeedData()
        {
            _staffUsers.Add(new StaffUser
            {
                Username = "admin",
                Password = "pass123",
                DisplayName = "Main Staff"
            });

            _residents.Add(new Resident
            {
                Id = 1,
                FullName = "Benjamin Igweze",
                Email = "bigweze@wtamu.edu",
                UnitNumber = "101"
            });

            _residents.Add(new Resident
            {
                Id = 2,
                FullName = "Don Trump",
                Email = "bcigweze1@buffs.wtamu.edu",
                UnitNumber = "102"
            });
        }

        // ===== LOGIN =====

        public bool Login(string username, string password)
        {
            return _staffUsers.Any(s =>
                s.Username.Equals(username, StringComparison.OrdinalIgnoreCase)
                && s.Password == password);
        }

        // ===== RESIDENT SEARCH =====

        public Resident? FindResident(string name, string unitNumber)
        {
            return _residents.FirstOrDefault(r =>
                r.FullName.Contains(name, StringComparison.OrdinalIgnoreCase)
                && r.UnitNumber.Equals(unitNumber, StringComparison.OrdinalIgnoreCase));
        }

        // ===== DELIVERED PACKAGE =====

        public Package RecordDeliveryForResident(Resident resident, string carrier, string trackingId)
        {
            var package = new Package
            {
                Id = _nextPackageId++,
                TrackingId = trackingId,
                Carrier = carrier,
                Status = PackageStatus.Pending,
                DeliveredDate = DateTime.Now,
                Resident = resident
            };

            _packages.Add(package);

            string subject = $"New Package Delivered: {trackingId}";
            string body = $"Dear {resident.FullName},\n\n" +
                          $"A package with tracking ID {trackingId} has been delivered " +
                          $"to the mailroom for unit {resident.UnitNumber}.\n\n" +
                          $"Thank you.";

            _emailService.SendPackageDeliveredEmail(resident.Email, subject, body);

            return package;
        }

        // ===== UNKNOWN PACKAGE =====

        public Package RecordUnknownPackage(string carrier, string trackingId, string unknownNote)
        {
            var package = new Package
            {
                Id = _nextPackageId++,
                TrackingId = trackingId,
                Carrier = carrier,
                Status = PackageStatus.Unknown,
                DeliveredDate = DateTime.Now,
                UnknownNote = unknownNote
            };

            _packages.Add(package);
            return package;
        }

        // ===== PICKUP =====

        public bool RecordPickup(string trackingId, out Package? package)
        {
            package = _packages.FirstOrDefault(p =>
                p.TrackingId.Equals(trackingId, StringComparison.OrdinalIgnoreCase));

            if (package == null)
            {
                return false;
            }

            package.Status = PackageStatus.PickedUp;
            package.PickedUpDate = DateTime.Now;
            return true;
        }

        // ===== HISTORY =====

        public List<Package> GetHistory(string residentName, string unitNumber)
        {
            return _packages
                .Where(p => p.Resident != null
                            && p.Resident.FullName.Contains(residentName, StringComparison.OrdinalIgnoreCase)
                            && p.Resident.UnitNumber.Equals(unitNumber, StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(p => p.DeliveredDate)
                .ToList();
        }

        public List<Package> GetAllPackages()
        {
            return _packages.OrderByDescending(p => p.DeliveredDate).ToList();
        }

        // ===== DELETE PACKAGE =====

        public bool DeletePackage(int id)
        {
            var package = _packages.FirstOrDefault(p => p.Id == id);
            if (package == null)
            {
                return false;
            }

            _packages.Remove(package);
            return true;
        }
    }
}
