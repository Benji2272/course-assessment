namespace MailroomApp.Models
{
    public class StaffUser
    {
        public string Username { get; set; } = "";
        public string Password { get; set; } = "";
        public string DisplayName { get; set; } = "";
    }
}
