using MailroomApp.Models;
using MailroomApp.Services;

var builder = WebApplication.CreateBuilder(args);

// Add MVC
builder.Services.AddControllersWithViews();

// Register our services (singletons – in-memory)
builder.Services.AddSingleton<MailroomSystem>();
builder.Services.AddSingleton<IEmailService, SmtpEmailService>();
builder.Services.AddTransient<MailroomApp.Services.EmailSender>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

// Default route: go to Login page
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");

app.Run();
