namespace MailroomApp.Services
{
    public interface IEmailService
    {
        void SendPackageDeliveredEmail(string toEmail, string subject, string body);
    }
}
