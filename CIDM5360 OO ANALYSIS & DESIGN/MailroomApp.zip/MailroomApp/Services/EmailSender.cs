using System.Net;
using System.Net.Mail;

namespace MailroomApp.Services
{
    public class EmailSender
    {
        private readonly string _senderEmail = "noreply@buffteks.org";     // from assignment
        private readonly string _password   = "cidm4360fall2024@*";       // from assignment

        public void Send(string toEmail, string subject, string body)
        {
            using (var message = new MailMessage())
            {
                message.From = new MailAddress(_senderEmail);
                message.To.Add(new MailAddress(toEmail));
                message.Subject = subject;
                message.Body = body;

                using (var smtpClient = new SmtpClient("mail.privateemail.com", 587))
                {
                    smtpClient.EnableSsl = true;
                    smtpClient.UseDefaultCredentials = false;
                    smtpClient.Credentials = new NetworkCredential(_senderEmail, _password);
                    smtpClient.Send(message);   // 🚀 this sends a LIVE email
                }
            }
        }
    }
}
