using System.Net;
using System.Net.Mail;

namespace MailroomApp.Services
{
    public class SmtpEmailService : IEmailService
    {
        // Use the sample credentials from the assignment
        private const string SenderEmail = "noreply@buffteks.org";
        private const string SenderPassword = "cidm4360fall2024@*";

        public void SendPackageDeliveredEmail(string toEmail, string subject, string body)
        {
            // Create the email message
            var message = new MailMessage();
            message.From = new MailAddress(SenderEmail);
            message.To.Add(new MailAddress(toEmail));
            message.Subject = subject;
            message.Body = body;
            message.IsBodyHtml = false;  // set to true if you pass HTML

            // Configure the SMTP client EXACTLY like the sample in the PDF
            using (var smtpClient = new SmtpClient("mail.privateemail.com", 587))
            {
                smtpClient.EnableSsl = true;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = new NetworkCredential(SenderEmail, SenderPassword);

                smtpClient.Send(message);
            }
        }
    }
}
