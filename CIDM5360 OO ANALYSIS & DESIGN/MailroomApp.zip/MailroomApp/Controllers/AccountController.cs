using Microsoft.AspNetCore.Mvc;
using MailroomApp.Models;

namespace MailroomApp.Controllers
{
    public class AccountController : Controller
    {
        private readonly MailroomSystem _mailroom;

        public AccountController(MailroomSystem mailroom)
        {
            _mailroom = mailroom;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            if (_mailroom.Login(username, password))
            {
                TempData["LoggedInUser"] = username;
                return RedirectToAction("Index", "Packages");
            }

            ViewBag.Error = "Invalid username or password.";
            return View();
        }
    }
}
