using Microsoft.AspNetCore.Mvc;
using MailroomApp.Models;

namespace MailroomApp.Controllers
{
    public class PackagesController : Controller
    {
        private readonly MailroomSystem _mailroom;

        public PackagesController(MailroomSystem mailroom)
        {
            _mailroom = mailroom;
        }

        public IActionResult Index()
        {
            var packages = _mailroom.GetAllPackages();
            return View(packages);
        }

        // ===== Record new delivery =====

        [HttpGet]
        public IActionResult RecordDelivery()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult RecordDelivery(
            string residentName,
            string unitNumber,
            string carrier,
            string trackingId)
        {
            var resident = _mailroom.FindResident(residentName, unitNumber);

            if (resident != null)
            {
                var pkg = _mailroom.RecordDeliveryForResident(resident, carrier, trackingId);

                // Email already sent inside MailroomSystem
                ViewBag.Message = $"Package {pkg.TrackingId} recorded and email sent to {resident.Email}.";
            }
            else
            {
                var pkg = _mailroom.RecordUnknownPackage(
                    carrier,
                    trackingId,
                    $"Unknown recipient: {residentName}, unit {unitNumber}");

                ViewBag.Message = $"Unknown package {pkg.TrackingId} recorded in UNKNOWN area.";
            }

            return View();
        }

        // ===== Pickup =====

        [HttpGet]
        public IActionResult Pickup()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Pickup(string trackingId)
        {
            bool success = _mailroom.RecordPickup(trackingId, out var package);

            if (success && package != null)
            {
                ViewBag.Message = $"Package {package.TrackingId} marked as PICKED UP.";
            }
            else
            {
                ViewBag.Message = $"Package with tracking ID {trackingId} not found.";
            }

            return View();
        }

        // ===== History =====

        [HttpGet]
        public IActionResult History()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult History(string residentName, string unitNumber)
        {
            var results = _mailroom.GetHistory(residentName, unitNumber);
            return View("HistoryResults", results);
        }

        // ===== Delete =====

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(int id)
        {
            bool success = _mailroom.DeletePackage(id);

            if (success)
            {
                TempData["Message"] = $"Package with Id {id} was deleted.";
            }
            else
            {
                TempData["Message"] = $"Package with Id {id} was not found.";
            }

            return RedirectToAction(nameof(Index));
        }
    }
}
